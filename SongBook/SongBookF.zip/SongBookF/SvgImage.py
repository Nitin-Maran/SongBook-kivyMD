SvgImage:
    source: "piano.svg"
    size_hint: None, None
    size: 250, 150
    pos_hint: {"center_x": 0.5}
